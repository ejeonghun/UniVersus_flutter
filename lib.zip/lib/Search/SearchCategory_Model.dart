import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'package:flutter/material.dart';
import 'package:universus/Search/SearchCategory_Widget.dart';

class SearchCategoryModel extends FlutterFlowModel<SearchCategoryWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
