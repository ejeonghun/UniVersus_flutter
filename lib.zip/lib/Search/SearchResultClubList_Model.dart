import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:universus/Search/SearchResultClubList_Widget.dart';

class SearchResultClubListModel
    extends FlutterFlowModel<SearchResultClubListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
