import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'recommendclub_widget.dart' show RecommendclubWidget;
import 'package:flutter/material.dart';

class RecommendclubModel extends FlutterFlowModel<RecommendclubWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
