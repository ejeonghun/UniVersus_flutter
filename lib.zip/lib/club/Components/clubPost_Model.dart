import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'clubPost_Widget.dart' show ClubPostWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ClubPostModel extends FlutterFlowModel<ClubPostWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
