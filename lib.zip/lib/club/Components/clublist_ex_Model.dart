import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'clublist_ex_Widget.dart' show ClublistExWidget;
import 'package:flutter/material.dart';

class ClublistExModel extends FlutterFlowModel<ClublistExWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}