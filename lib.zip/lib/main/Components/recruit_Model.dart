import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'package:http/http.dart';
import 'package:universus/class/user/user.dart';
import 'package:universus/main/Components/recruitmentElement.dart';
import 'recruit_Widget.dart' show RecruitWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RecruitModel extends FlutterFlowModel<RecruitWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}