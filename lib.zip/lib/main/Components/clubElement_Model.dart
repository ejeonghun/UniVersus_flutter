import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'clubElement_Widget.dart' show ClubElementWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ClubElementModel extends FlutterFlowModel<ClubElementWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
